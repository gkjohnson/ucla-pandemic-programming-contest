//------------------------------------------------------------------
// AIBotExample.cpp : Replace code here!
//------------------------------------------------------------------	

#include "DllEntry.h"
#include <windows.h>
#include <time.h>
#include <algorithm>

void DrawAiPaths(const sWorldInfo &mWorldInfo,  void (*DrawLine)(vec2,vec2,vColor,float));

extern "C" __declspec(dllexport)
void dllmonsteraction(const float dt, 
					  sEntInfo &mEnt, 
					  const sWorldInfo &mWorldInfo, 
					  void (*DrawLine)(vec2,vec2,vColor,float))
{
	// Find a target that's still alive.
	const sOtherEnts *pTarget = 0;
	static int iCount=0;
	for(int i = 0; i < mWorldInfo.iNumOtherEnts; ++i)
	{
		/*
		if(mWorldInfo.pOtherEnts[i].type == TYPE_FIREBALL)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_ROCKET)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_GRENADE)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_SHOTGUN_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_CHAINGUN_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_ROCKET_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_RIFLE_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_GRENADE_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_HEALTH_PICKUP)
			iCount++;
		else if(mWorldInfo.pOtherEnts[i].type == TYPE_TELEPORT)
			iCount++;
		*/

		if(mWorldInfo.pOtherEnts[i].type == TYPE_ENEMY && mWorldInfo.pOtherEnts[i].iHealth > 0)
		{
			pTarget = &mWorldInfo.pOtherEnts[i];
			//break;
		}
	}


	// Move to the last click position
	// vec2(0,0) as mWorldInfo.vLastMouseClick is the initial value, so we can ignore that.
	const float fDistanceToSpot = Length(mWorldInfo.vLastMouseClick - mEnt.pos);
	if(fDistanceToSpot < 4.f || (mWorldInfo.vLastMouseClick == vec2(0,0)))
	{
		// Stand still.
		mEnt.moveDirection = vec2(0.0f, 0.0f);
	}
	else
	{
		// Build the move direction. This must be a normalized direction vector.
		mEnt.moveDirection = Normalize(mWorldInfo.vLastMouseClick - mEnt.pos);

		// You can draw lines for debugging with the Drawline function pointer passed in.
		// Note that there are some predefined colors in DllEntry.h, or you can make your own.
		// DrawLine(start, end, color, duration)
		//DrawLine(mEnt.pos, mWorldInfo.vLastMouseClick, MAGENTA, 0.f);
	}

	// Full speed ahead always.
	mEnt.fMoveSpeed = MAX_ENT_SPEED;
	//mEnt.fMoveSpeed = 0;
	if(pTarget)
	{
		//mEnt.nextCommand = OP_SHOOT_CHAINGUN;
		/*
		if(mEnt.iGrenades>0)
			mEnt.nextCommand = OP_SHOOT_GRENADE;
		else if(mEnt.iShotgunShells>0)
			mEnt.nextCommand = OP_SHOOT_SHOTGUN;
		else if(mEnt.iChaingunBullets>0)
			mEnt.nextCommand = OP_SHOOT_CHAINGUN;
		else if(mEnt.iRockets>0)
			mEnt.nextCommand = OP_SHOOT_ROCKET;
		else if(mEnt.iRifleBullets>0)
			mEnt.nextCommand = OP_SHOOT_RIFLE;
		else
			mEnt.nextCommand = OP_SHOOT_FIREBALL;
		*/
		// Always aim at the target.
		vec2 pos = pTarget->pos;
		pos += vec2(5, 0);
		mEnt.aimDirection = Normalize(pos - mEnt.pos);
	}
	else
	{
		mEnt.nextCommand = OP_ANIM_WIN;
	}

	DrawAiPaths(mWorldInfo, DrawLine);
}


void DrawAiPaths(const sWorldInfo &mWorldInfo,  void (*DrawLine)(vec2,vec2,vColor,float))
{
	//first find best fit
	vec2 vMin = vec2( 10000,  10000);
	vec2 vMax = vec2(-10000, -10000);

	for(int i=0; i<mWorldInfo.iNumPathNodes; i++)
	{
		sPathNode *pathEnt1 = &mWorldInfo.pPathNodes[i];
		if(pathEnt1->vPos.x < vMin.x)
			vMin.x = pathEnt1->vPos.x;
		if(pathEnt1->vPos.x > vMax.x)
			vMax.x = pathEnt1->vPos.x;

		if(pathEnt1->vPos.y < vMin.y)
			vMin.y = pathEnt1->vPos.y;
		if(pathEnt1->vPos.y > vMax.y)
			vMax.y = pathEnt1->vPos.y;
	}

	float fGridSize = 8.0f;
	//int numX = (vMax.x - vMin.x)/fGridSize;
	//int numY = (vMax.y - vMin.y)/fGridSize;


	//now fill in 2d array of map
	const int XGRID_MAX=70;
	const int YGRID_MAX=70;
	bool pathGrid[XGRID_MAX][YGRID_MAX];
	memset(&pathGrid, 0, sizeof(bool)*XGRID_MAX*YGRID_MAX);
	for(int i=0; i<mWorldInfo.iNumPathNodes; i++)
	{
		sPathNode *pathEnt1 = &mWorldInfo.pPathNodes[i];

		if(pathEnt1->vPos.x>=vMin.x && pathEnt1->vPos.x<=vMax.y &&
			pathEnt1->vPos.y>=vMin.y && pathEnt1->vPos.y<=vMax.y)
		{
			int xPos = (pathEnt1->vPos.x - vMin.x) / fGridSize;
			int yPos = (pathEnt1->vPos.y - vMin.y) / fGridSize;

			pathGrid[xPos][yPos] = true;
		}
	}

	//draw lines along y axis
	for(int x=0; x<XGRID_MAX; x++)
	{
		bool bInLine = false;
		vec2 vLineStart;
		for(int y=0; y<YGRID_MAX; y++)
		{
			if(pathGrid[x][y] && !bInLine)
			{
				vLineStart.x = vMin.x + x*fGridSize;
				vLineStart.y = vMin.y + y*fGridSize;
				bInLine = true;
			}

			if(!pathGrid[x][y] && bInLine)
			{
				vec2 vLineEnd;
				vLineEnd.x = vMin.x + x*fGridSize;
				vLineEnd.y = vMin.y + (y-1)*fGridSize;
				DrawLine(vLineStart, vLineEnd, GREEN, 0.0f);
				bInLine = false;
			}
		}
	}

	//draw lines along x axis
	for(int y=0; y<YGRID_MAX; y++)
	{
		bool bInLine = false;
		vec2 vLineStart;
		for(int x=0; x<XGRID_MAX; x++)
		{
			if(pathGrid[x][y] && !bInLine)
			{
				vLineStart.x = vMin.x + x*fGridSize;
				vLineStart.y = vMin.y + y*fGridSize;
				bInLine = true;
			}

			if(!pathGrid[x][y] && bInLine)
			{
				vec2 vLineEnd;
				vLineEnd.x = vMin.x + (x-1)*fGridSize;
				vLineEnd.y = vMin.y + y*fGridSize;
				DrawLine(vLineStart, vLineEnd, GREEN, 0.0f);
				bInLine = false;
			}
		}
	}

	//look for nodes with no connections
	for(int i=0; i<mWorldInfo.iNumPathNodes; i++)
	{
		sPathNode *pathEnt1 = &mWorldInfo.pPathNodes[i];
		bool bFoundConnection = false;
		for(int j=0; j<4; j++)
		{
			if(pathEnt1->connectingNodeIndex[j]!=-1)
			{
				bFoundConnection = true;
				break;
			}
		}

		if(bFoundConnection)
			continue;

		vec2 vTop = pathEnt1->vPos + vec2(0,4);
		vec2 vBot = pathEnt1->vPos + vec2(0,-4);
		vec2 vRight = pathEnt1->vPos + vec2(4,0);
		vec2 vLeft = pathEnt1->vPos+ vec2(-4,0);

		DrawLine(vTop, vBot, GREEN, 0.0f);
		DrawLine(vRight, vLeft, GREEN, 0.0f);
	}


	/*
	//old slow way
	for(int i=0; i<mWorldInfo.iNumPathNodes; i++)
	{
		sPathNode *pathEnt1 = &mWorldInfo.pPathNodes[i];
		for(int j=0; j<4; j++)
		{
			if(pathEnt1->connectingNodeIndex[j]!=-1)
			{
				sPathNode *pathEnt2 = &mWorldInfo.pPathNodes[pathEnt1->connectingNodeIndex[j]];
				//DrawLine(pathEnt1->vPos, pathEnt2->vPos, GREEN, 0.0f); 
			}
		}
	}
	*/
}