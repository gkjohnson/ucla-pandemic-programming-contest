http://jonathanclark.com/golgotha/browse.html
Free to use for non commercial use in games and 3D applications.




http://www.vb3d.com/Textures.html
Synopsis:
These are some free game textures from the Golgotha game. The game was cancelled and all it's art put into the public domain. Very Useful. I am not sure of the author but to whoever, thank you. I hope you guys can make use of these too.

