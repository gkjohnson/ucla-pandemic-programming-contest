Quad model by Dietmar "DCP" Pier. 
www.dietmarpier.de

Converted to .md3 and spec/glowmap added by makkE
