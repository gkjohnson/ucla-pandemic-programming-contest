This directory contains "packages" of textures and other materials
for use with the engine, in their respective subdirectories.

In most cases these are modified/selected sets by me, refer to
the original readme's how to obtain the full sets, and copyright /
author information.

