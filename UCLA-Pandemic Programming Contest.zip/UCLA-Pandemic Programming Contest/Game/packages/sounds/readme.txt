This directory contains game sounds

The "free" ones are sounds taken off the web, from sites
that guarantee these are free to use & original sounds.

The "awesund" ones are from Sin sound replacement packs,
see included readme.

The "aard" ones are all 100% original material, often
created with my own voice or otherwise. They are hereby
placed in the public domain as well.

awesund/Rifle.wav and free/shotgun.wav were modified by Darthvim.